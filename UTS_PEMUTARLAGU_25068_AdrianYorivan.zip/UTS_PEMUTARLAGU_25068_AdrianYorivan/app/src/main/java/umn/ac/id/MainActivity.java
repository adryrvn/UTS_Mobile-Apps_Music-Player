package umn.ac.id;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnProfile, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setTitle("Adrian Yorivan - 00000025068");
        setContentView(R.layout.activity_main);


        btnProfile = (Button) findViewById(R.id.btnProfil);
        btnLogin = (Button) findViewById(R.id.btnLogin);


        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProfile();
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLogin();
            }
        });


    }



    public void openProfile() {
        Intent intent = new Intent(this, PageProfile.class);
        startActivity(intent);
    }

    public void openLogin() {
        Intent intent = new Intent(this, PageLogin.class);
        startActivity(intent);
    }
}