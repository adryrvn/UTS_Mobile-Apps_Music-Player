package umn.ac.id;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PageProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_profile);
        this.setTitle("Profile Saya");
    }
}